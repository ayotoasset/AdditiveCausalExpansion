#obsolete - see utilities_cpp for the normalization
