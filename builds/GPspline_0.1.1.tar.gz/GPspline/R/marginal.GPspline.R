marginal.GPspline <- function(){

}
