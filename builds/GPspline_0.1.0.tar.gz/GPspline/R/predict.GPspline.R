predict.GPspline <- function(){

  #normalize_test(y,X,Z,GPspline$moments) #data is referenced, argout: void


}
