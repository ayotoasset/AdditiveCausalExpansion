ace.cv <- function(y, X, Z, pi, length_scales=c(0.1, 1, 5, 10, 15, 20, 30), ...) {

  verbose <- FALSE
  # initial values (20 approx linear model):
  best_object <- object <- ace.train(y, X, Z, pi,
                                        plot_stats = FALSE,
                                        verbose = verbose, ...) #length_sclae = 20


  # append parameter lists:
  length_scales <- length_scales[length_scales!=20]
  nr_runs <- length(length_scales)

  log_evidences = rep(0, nr_runs+1)
  log_evidences[1] = best_object$train_stats$final_evidence

  for (i in 1:nr_runs) {
    object <- ace.train(y, X, Z, pi,
                        plot_stats = FALSE, init.length_scale = length_scales[i],
                        verbose = verbose, ...)

    log_evidences[1 + i] = object$train_stats$final_evidence
    cat(sprintf("Initial length scale: %4.2f | Converged %d | Final log evidence %4.2f\n",
                length_scales[i], object$train_stats$convergence, object$train_stats$final_evidence))

    #only keep best and when converged
    if (object$train_stats$convergence) {
      if (object$train_stats$final_evidence > best_object$train_stats$final_evidence) {
        best_object <- object
      }
    } else {
      cat("No convergence for length scale: ", length_scales[i])
    }

    # end for
  }

  plot(c(20, length_scales), log_evidences)

  cat("Highest log evidence for length scale: ", best_object$train_stats$init.length_scale, "\n")
  invisible(best_object)
}

