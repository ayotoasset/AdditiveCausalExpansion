plot.GPspline <- function(){

  #ggplot() ????? for 3D graph
  #plot() to reduce dependencies? trycatch(ggplot2)?


  #3d with formula: name-based?

}
